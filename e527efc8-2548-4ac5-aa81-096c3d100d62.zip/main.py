
mpg = float(input())
cpg = float(input())
cost_20 = 20 / mpg * cpg
cost_75 = 75 / mpg * cpg
cost_500 = 500 / mpg * cpg

print(f'{cost_20:.2f} {cost_75:.2f} {cost_500:.2f}')