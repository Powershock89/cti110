def days_in_feb(user_year):
    days = 28
    
    if (user_year % 4) == 0:        # user_year is divisible by 4
        if ((user_year % 100) ==0):     # user_year is divisible by 100 (century year)
            if ((user_year % 400) == 0): # user_year is divisible by 400
                days = 29   
        else:       # user_year is not divisible by 100
            days = 29
                
    return days
        
if __name__ == '__main__':
    user_input = int(input())
        
    print(f'{user_input} has {days_in_feb(user_input)} days in February.')